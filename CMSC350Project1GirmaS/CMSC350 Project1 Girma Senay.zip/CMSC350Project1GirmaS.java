
/**
 * CMSC350Project1GirmaS.java - a class where all user interface is implemented to enter value to be converted to Postfix
 * or Prefix, select the type of conversion, and a display the converted value. This class instantiates and implements the 
 * Converter and ExceptionHandler classes to achieve proper conversion and error handling. 
 * 
 * @author  Girma, Senay
 * @version 1.0 08/30/2022
 * Project 1
 */
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class CMSC350Project1GirmaS extends JFrame implements ActionListener {
	
	private JTextField inputExpressionTextField, resultExpressionTextField;
	private JLabel inputFieldLabel, resultFieldLabel;
	
	public CMSC350Project1GirmaS() {
		// create labels
		inputFieldLabel = new JLabel("Enter Expression ");
		resultFieldLabel = new JLabel("Result ");
		
		//input text fields
		inputExpressionTextField = new JTextField(20);
		resultExpressionTextField = new JTextField(20);
	
		//create buttons
		JButton prefixToPostfixButton = new JButton("Prefix To Postfix");
		JButton postfixToPrefixButton = new JButton("Postfix To Prefix");
		
		setTitle("Expression Converter");
		setSize(400,150);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setLayout(new GridLayout(3,1));
	
		JComponent[] userInputComponents = {inputFieldLabel, inputExpressionTextField};
		addComponentsToPanel(userInputComponents);	
		
		JComponent[] controlComponents = {prefixToPostfixButton, postfixToPrefixButton};
		addComponentsToPanel(controlComponents);

		JComponent[] outputComponents = {resultFieldLabel, resultExpressionTextField};
		addComponentsToPanel(outputComponents);
		
		prefixToPostfixButton.addActionListener(this);
		postfixToPrefixButton.addActionListener(this);
		
	}
	
	private void addComponentsToPanel(JComponent[] components) {
		JPanel panel = new JPanel();
		panel.setLayout(new FlowLayout());
		
		for(Component component: components)
			panel.add(component);
		add(panel);
	}
	
	@Override
	public void actionPerformed(ActionEvent e) {
		String expression = inputExpressionTextField.getText();
		String noInputErrorMessage = "You have not provided a value to be converted. Please try again.";

		if((expression==null) || expression.trim().isEmpty()) {
			JOptionPane.showMessageDialog(new JFrame(), noInputErrorMessage, "Dialog", JOptionPane.ERROR_MESSAGE);
		}
		
		//ExpressionConverter converter = new ExpressionConverter(expression);
		try {
		switch(e.getActionCommand()) {
		case "Prefix To Postfix":{
			ExpressionConverter converter = new ExpressionConverter(expression);
			System.out.println(converter.convertPrefixToPostfix());
			resultExpressionTextField.setText(converter.convertPrefixToPostfix());
			//System.out.println("prefix to postfix selected for label " + inputExpressionTextField.getText());
		}
		break;
		
		case "Postfix To Prefix":{
			ExpressionConverter converter = new ExpressionConverter(expression);
			resultExpressionTextField.setText(converter.convertPostfixToPrefix());
			System.out.println("Postfix to prefix1 selected for label " + resultExpressionTextField.getText());
		}
		break;
		}
		}catch(StackSizeException exception){
			JOptionPane.showMessageDialog(new JFrame(), exception.toString(), "Dialog", JOptionPane.ERROR_MESSAGE);

		}
	}

	public static void main(String[] args)
	{
		CMSC350Project1GirmaS converterGUI = new CMSC350Project1GirmaS();
		converterGUI.setVisible(true);
	}
}

